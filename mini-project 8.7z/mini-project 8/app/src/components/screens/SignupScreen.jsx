import React from 'react'

function SignupScreen() {
  return (
    <div>SignupScreen</div>
  )
}

export default SignupScreen