import React from 'react'
import {Container} from 'react-bootstrap'


function Footer() {
  return (
    <footer>
      <Container>
       Footer
      </Container>
    </footer>
  )
}

export default Footer